Je voudrais présenter certaines de mes améliorations sur ce TP: 
-J'ai d'abord ajouté quelques icônes au site Web pour le rendre plus vivant.
-Puis j'ai utilisé CSS pour masquer la liste de musique des chanteurs, quand on veut afficher la liste j'ai appliqué jQuery pour créer un événement de "click" lorsque l'utilisateur clique dessus, il affichera la liste de musique.
-J'ai ajouté des chansons, nous pouvons écouter, mettre en pause, accélérer la lecture en appuyant sur le bouton à côté de la chanson.
